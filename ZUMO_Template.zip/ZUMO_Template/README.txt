ZUMO TEMPLATE — DO NOT WORK IN THIS FOLDER
==========================================
Start every lesson the same way:

1. COPY this whole folder (in Documents/PlatformIO)
2. RENAME the copy:  LastName_L##   (example: Smith_L03)  — NO SPACES
3. In VS Code:  File > Open Folder > pick your new copy
   (close the previous lesson's folder first!)
4. Update the header comment in src/main.cpp — name, date, lesson
5. Click Build (checkmark). SUCCESS = your copy is healthy. Start the lesson.
